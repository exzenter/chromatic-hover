=== Chromatic Aberration Hover ===
Contributors: exzent.de
Tags: chromatic, hover, mask, logo
Requires at least: 5.0
Tested up to: 6.9
Stable tag: 0.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Adds a configurable chromatic aberration mask that follows the cursor on specified elements. Settings allow you to control the selectors, colors, shadow size, mask radius, and tracking mode.

